package com.daycare.app.backend.models;

public enum UserRole {
    ROLE_USER, ADMIN, MODERATOR, SELLER
}
