package com.daycare.app.backend.constant;

public class EcommerceConstant {
    public static enum STATUS{
         OK, NOT_OK
    }
    
    public static enum ORDER_STATUS{
        APPROVED, REGECTED, PENDING
   }
}
